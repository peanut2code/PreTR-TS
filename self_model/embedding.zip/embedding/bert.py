import torch.nn as nn
from .token import TokenEmbedding
from .position import PositionalEmbedding
from .segment import SegmentEmbedding
import torch.nn.functional as F

class BERTEmbedding(nn.Module):
    """
    BERT Embedding which is consisted with under features
        1. TokenEmbedding : normal embedding matrix
        2. PositionalEmbedding : adding positional information using sin, cos
        2. SegmentEmbedding : adding sentence segment info, (sent_A:1, sent_B:2)

        sum of all these features are output of BERTEmbedding
    """

    def __init__(self, input_size, embed_size, spots_len=603,dropout=0.1):
        """
        :param vocab_size: total vocab size
        :param embed_size: embedding size of token embedding
        :param dropout: dropout rate
        """
        super().__init__()
        # self.token = TokenEmbedding(vocab_size=vocab_size, embed_size=embed_size)

        # 将27维向量映射到hidden层神经元数量维度向量
        #self.l1 = nn.Linear(input_size, embed_size)
        self.l1 = nn.Linear(87, embed_size) #二分类和多分类都是 59
        
        #self.position = PositionalEmbedding(d_model=embed_size,max_len=spots_len)

        #self.segment = SegmentEmbedding(embed_size=embed_size)
        #self.LayerNorm = nn.LayerNorm(embed_size, eps=1e-5)
        self.dropout = nn.Dropout(p=dropout)
        self.embed_size = embed_size

    def forward(self, sequence, segment_label):
        #print('sequence:', sequence.shape)
        emb = self.l1(sequence)
        # x = self.token(sequence) + self.position(sequence) + self.segment(segment_label)

        # print('embd')
        # print(emb.shape)
        # print('seg')
        # print(self.segment(segment_label).shape)
        # print('position')
        # print(self.position(sequence).shape)
        # print('end')
        # print('sequence:', sequence.shape)
        # print('emb:', emb.shape)
        #print('segment_label:', segment_label)
        x = emb #+ self.segment(segment_label) #self.position(sequence) #
        # x = emb  + self.segment(segment_label)
        #x = emb
        #print('x:', x.shape)
        #x = self.LayerNorm(x)
        return self.dropout(x)
